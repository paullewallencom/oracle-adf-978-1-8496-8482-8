package fmwk.extension.view;
/**
 * Transaction context interface, used to pass the txn context to 
 * third paty services for data manipulation. As of this body is kept empty.
 * Modify it as per your use case
 */
public interface TransactionContext {
 
}
