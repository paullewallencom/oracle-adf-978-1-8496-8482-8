package fmwk.extension.view;

/**
 * This can hold  valid transaction context which needs to be passed to the
 * third party service one data manilpulation. 
 * As of now its left blank :)
 */
public class DefaultTransactionContext implements TransactionContext {
    public DefaultTransactionContext() {
        super();
    }
}
