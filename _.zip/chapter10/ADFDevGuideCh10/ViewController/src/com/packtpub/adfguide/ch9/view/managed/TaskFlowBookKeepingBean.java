package com.packtpub.adfguide.ch9.view.managed;

public class TaskFlowBookKeepingBean {
    public TaskFlowBookKeepingBean() {
        super();
    }
    public void initializer(){
        System.out.println("--initializer--");
    }
    public void finalizer(){
        System.out.println("--finalizer--");
    }
}
