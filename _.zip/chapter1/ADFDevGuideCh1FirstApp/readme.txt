Notes
-----
Please go through the instructions before you run the sample.

Extract the zip file to your local file system.
Open ADFDevGuideCh1FirstApp workspace in JDeveloper 11.1.2.2.0 or higher

The sample ADFDevGuideCh1FirstApp uses HR schema as database.

To run the sample please follow the steps listed below:
1. Change the database connection setting to reflect your local database settings.
   To change the connection,
   1.1 Goto Application Resources panel and expand Connections | Database.
   1.2 Right click the HR connection and choose properties. In the Edit Database Connection dialog change the settings to point to your local database
2. Right click departaments.jsf in the application navigator window, and choose Run    
  
